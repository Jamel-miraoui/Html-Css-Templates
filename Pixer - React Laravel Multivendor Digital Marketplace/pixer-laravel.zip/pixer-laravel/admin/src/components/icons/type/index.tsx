export { NoTypeIcon } from './no-type-icon';
export { FixedIcon } from './fixed-icon';
export { LiquidIcon } from './liquid-icon';
export { ResponsiveIcon } from './responsive-icon';

// TODO : this icon area need to be checked in Pixer.

// export { FruitsVegetable } from './fruits-vegetable';
// export { FacialCare } from './facial-care';
// export { Handbag } from './handbag-icon';
// export { DressIcon } from './dress-icon';
// export { FurnitureIcon } from './furniture-icon';
// export { BookIcon } from './book-icon';
// export { MedicineIcon } from './medicine-icon';
// export { Restaurant } from './restaurant-icon';
// export { Bakery } from './bakery-icon';
export { BabyCare } from './baby-care-icon';
export { Plant } from './plant-icon';
export { MicroGreens } from './micro-greens-icon';
export { HomeAppliance } from './home-appliance-icon';
export { Gadgets } from './gadgets-icon';
