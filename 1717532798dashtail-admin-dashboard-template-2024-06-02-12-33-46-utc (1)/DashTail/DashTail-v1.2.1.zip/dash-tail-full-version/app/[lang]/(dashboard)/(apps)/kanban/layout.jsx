const layout = ({ children }) => {
  return <>{children}</>;
};

export default layout;
