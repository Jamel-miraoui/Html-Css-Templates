export const metadata = {
  title: "Chat",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
