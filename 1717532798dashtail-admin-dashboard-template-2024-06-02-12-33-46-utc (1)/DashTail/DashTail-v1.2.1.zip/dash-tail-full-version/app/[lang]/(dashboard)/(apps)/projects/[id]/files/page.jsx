
import ViewFiles from "@/components/files/view-files"
const FilessPage = ()=>{
  return(
    <ViewFiles/>
  )
}
export default FilessPage;
