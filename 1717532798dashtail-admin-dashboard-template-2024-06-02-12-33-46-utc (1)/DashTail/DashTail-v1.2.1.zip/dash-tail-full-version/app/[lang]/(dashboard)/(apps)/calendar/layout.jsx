export const metadata = {
  title: "Calender",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
