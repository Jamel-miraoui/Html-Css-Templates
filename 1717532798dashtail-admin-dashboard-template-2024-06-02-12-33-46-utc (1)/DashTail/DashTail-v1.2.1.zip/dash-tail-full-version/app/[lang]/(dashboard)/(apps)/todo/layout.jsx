export const metadata = {
  title: "Todo",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
