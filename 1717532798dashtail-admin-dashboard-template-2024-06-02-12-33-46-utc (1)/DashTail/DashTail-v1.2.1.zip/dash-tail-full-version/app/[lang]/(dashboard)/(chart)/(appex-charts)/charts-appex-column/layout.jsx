export const metadata = {
  title: "Appex Column Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
