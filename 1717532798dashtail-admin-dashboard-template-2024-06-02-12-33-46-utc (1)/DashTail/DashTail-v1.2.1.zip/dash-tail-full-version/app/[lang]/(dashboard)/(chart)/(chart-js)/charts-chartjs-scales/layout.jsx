export const metadata = {
  title: "Chart-js Scale Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
