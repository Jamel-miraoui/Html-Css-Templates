export const metadata = {
  title: "Appex Bubble Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
