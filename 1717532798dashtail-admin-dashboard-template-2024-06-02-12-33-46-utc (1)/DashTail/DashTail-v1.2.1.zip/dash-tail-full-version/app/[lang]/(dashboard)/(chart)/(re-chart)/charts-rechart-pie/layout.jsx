export const metadata = {
  title: "Rechart Pie Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
