export const metadata = {
  title: "Appex Radar Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
