export const metadata = {
  title: "Unovis Area Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
