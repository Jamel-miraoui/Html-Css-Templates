export const metadata = {
  title: "Appex Timeline Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
