export const metadata = {
  title: "Appex Scatter Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
