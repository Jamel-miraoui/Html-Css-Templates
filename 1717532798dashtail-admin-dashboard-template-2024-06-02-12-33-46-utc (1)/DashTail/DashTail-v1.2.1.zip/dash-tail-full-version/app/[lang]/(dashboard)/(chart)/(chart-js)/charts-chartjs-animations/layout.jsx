export const metadata = {
  title: "Chart-js Animation Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
