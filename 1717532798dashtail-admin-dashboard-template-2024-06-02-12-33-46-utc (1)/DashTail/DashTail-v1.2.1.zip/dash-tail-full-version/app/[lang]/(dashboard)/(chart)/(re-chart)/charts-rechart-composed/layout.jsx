export const metadata = {
  title: "Rechart Composed Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
