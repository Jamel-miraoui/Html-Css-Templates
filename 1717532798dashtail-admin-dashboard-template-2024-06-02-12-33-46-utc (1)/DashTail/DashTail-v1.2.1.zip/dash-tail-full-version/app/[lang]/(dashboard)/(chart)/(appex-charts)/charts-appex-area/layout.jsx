export const metadata = {
  title: "Appex Area Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
