export const metadata = {
  title: "Rechart Radar Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
