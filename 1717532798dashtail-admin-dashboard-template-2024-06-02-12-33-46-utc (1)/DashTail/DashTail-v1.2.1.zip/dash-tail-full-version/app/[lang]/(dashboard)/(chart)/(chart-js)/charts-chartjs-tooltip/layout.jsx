export const metadata = {
  title: "Chart-js Tooltip Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
