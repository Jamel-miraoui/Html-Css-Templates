export const metadata = {
  title: "Rechart Area Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
