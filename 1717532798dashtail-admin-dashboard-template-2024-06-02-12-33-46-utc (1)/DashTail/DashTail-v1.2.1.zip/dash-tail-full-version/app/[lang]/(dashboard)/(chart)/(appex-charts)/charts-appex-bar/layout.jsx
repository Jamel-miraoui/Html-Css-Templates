export const metadata = {
  title: "Appex Bar Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
