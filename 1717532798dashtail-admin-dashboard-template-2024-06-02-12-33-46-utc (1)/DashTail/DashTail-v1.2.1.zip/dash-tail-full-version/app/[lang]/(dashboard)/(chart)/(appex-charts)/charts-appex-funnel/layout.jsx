export const metadata = {
  title: "Appex Funnel Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
