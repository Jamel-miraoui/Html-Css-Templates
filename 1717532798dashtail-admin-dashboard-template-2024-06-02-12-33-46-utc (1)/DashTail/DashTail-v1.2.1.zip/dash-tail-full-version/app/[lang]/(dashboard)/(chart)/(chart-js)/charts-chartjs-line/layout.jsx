export const metadata = {
  title: "Chart-js Line Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
