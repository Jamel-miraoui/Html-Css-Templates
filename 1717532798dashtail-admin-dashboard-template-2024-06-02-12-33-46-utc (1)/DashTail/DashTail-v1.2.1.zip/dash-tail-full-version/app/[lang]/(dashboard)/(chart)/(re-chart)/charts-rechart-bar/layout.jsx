export const metadata = {
  title: "Rechart Bar Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
