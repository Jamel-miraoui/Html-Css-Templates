export const metadata = {
  title: "Appex Pie Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
