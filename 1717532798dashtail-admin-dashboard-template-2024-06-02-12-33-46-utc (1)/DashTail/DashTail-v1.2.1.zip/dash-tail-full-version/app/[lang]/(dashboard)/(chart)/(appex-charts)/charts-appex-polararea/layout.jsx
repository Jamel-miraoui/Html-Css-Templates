export const metadata = {
  title: "Appex Polar Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
