export const metadata = {
  title: "Rechart Tree Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
