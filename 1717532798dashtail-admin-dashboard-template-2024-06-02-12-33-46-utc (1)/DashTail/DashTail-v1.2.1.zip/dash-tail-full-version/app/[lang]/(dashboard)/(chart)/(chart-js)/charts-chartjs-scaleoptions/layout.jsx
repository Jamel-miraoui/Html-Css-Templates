export const metadata = {
  title: "Chart-js Scale Option Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
