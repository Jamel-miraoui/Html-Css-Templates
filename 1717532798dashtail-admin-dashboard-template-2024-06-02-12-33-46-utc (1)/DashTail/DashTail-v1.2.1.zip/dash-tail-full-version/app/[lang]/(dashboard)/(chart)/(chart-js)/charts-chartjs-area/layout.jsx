export const metadata = {
  title: "Chart-js Area Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
