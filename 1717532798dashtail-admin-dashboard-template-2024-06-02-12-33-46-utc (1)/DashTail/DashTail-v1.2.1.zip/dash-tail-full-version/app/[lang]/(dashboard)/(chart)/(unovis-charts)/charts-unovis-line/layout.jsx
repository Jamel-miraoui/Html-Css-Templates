export const metadata = {
  title: "Unovis Line Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
