export const metadata = {
  title: "Chart-js Title Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
