export const metadata = {
  title: "Unovis Bar Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
