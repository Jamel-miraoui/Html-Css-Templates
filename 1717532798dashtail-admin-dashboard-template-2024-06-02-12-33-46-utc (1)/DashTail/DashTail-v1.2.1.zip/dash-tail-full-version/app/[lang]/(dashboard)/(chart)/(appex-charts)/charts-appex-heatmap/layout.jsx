export const metadata = {
  title: "Appex Heatmap Chart,",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
