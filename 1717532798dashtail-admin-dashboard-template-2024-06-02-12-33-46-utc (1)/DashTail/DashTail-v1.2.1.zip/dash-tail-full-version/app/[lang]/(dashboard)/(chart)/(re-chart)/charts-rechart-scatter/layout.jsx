export const metadata = {
  title: "Rechart Scatter Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
