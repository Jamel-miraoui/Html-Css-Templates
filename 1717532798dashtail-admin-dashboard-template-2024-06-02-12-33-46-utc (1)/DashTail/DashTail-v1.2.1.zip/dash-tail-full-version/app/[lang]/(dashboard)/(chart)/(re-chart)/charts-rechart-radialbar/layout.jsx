export const metadata = {
  title: "Rechart Radialbar Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
