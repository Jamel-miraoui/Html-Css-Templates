export const metadata = {
  title: "Chart-js Scriptable Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
