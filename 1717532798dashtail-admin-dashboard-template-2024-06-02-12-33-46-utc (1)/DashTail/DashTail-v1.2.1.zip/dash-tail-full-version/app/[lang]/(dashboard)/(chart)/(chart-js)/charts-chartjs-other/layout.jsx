export const metadata = {
  title: "Chart-js Other Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
