export const metadata = {
  title: "Chart-js Bar Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
