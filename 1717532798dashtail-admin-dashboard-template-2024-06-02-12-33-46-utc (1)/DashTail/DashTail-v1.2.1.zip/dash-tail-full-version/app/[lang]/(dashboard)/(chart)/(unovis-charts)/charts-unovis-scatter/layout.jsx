export const metadata = {
  title: "Unovis Scatter Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
