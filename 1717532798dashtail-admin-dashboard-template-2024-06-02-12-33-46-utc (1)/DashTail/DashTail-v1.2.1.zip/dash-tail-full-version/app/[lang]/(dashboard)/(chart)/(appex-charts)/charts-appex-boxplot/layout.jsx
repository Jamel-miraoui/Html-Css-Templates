export const metadata = {
  title: "Appex Boxplot Chart",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
