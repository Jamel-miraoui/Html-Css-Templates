

const HighlightAndZoom = () => {
    return (
        <div>

        </div>
    );
};

export default HighlightAndZoom;