export const metadata = {
  title: "Appex Range Chart ",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
