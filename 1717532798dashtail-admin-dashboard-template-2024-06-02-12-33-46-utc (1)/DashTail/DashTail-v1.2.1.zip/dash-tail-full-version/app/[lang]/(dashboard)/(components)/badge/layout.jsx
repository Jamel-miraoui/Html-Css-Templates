export const metadata = {
  title: "Badge",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
