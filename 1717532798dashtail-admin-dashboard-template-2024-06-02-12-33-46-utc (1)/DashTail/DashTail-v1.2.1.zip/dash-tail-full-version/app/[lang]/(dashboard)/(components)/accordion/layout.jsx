export const metadata = {
  title: "Accordion",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
