export const metadata = {
  title: "Alert",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
