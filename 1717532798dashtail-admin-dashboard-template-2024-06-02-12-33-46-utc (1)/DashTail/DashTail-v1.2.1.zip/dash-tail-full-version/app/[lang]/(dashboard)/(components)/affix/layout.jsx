export const metadata = {
  title: "Affix",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
