export const metadata = {
  title: "Breadcrumb",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
