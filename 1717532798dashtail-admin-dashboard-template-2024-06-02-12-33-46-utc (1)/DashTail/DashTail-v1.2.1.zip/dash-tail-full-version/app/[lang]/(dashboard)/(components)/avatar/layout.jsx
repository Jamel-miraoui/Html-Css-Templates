export const metadata = {
  title: "Avatar",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
