export const metadata = {
  title: "Button",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
