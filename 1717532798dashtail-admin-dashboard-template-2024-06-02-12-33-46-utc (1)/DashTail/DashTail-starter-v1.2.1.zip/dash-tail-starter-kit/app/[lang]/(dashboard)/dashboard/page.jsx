import React from "react";

const page = () => {
  return <div className="text-2xl font-semibold">Start Your Content...</div>;
};

export default page;
