import React from "react";
import Link from "next/link";
//import ErrorBlock from "@/components/error-block";

const PageNotFound = () => {
  return <div>ami error..</div>;
};

export default PageNotFound;
