"use client";

const AuthProvider = ({ children }) => {
  return <>{children}</>;
};

export default AuthProvider;
