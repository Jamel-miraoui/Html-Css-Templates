export { default as Watermark } from "./watermark";
