<?php
/**
 * Template Name: Full Width Page
 *
 * @package Hostim
 * @since 3.5.1
 */

get_header();
?>

<div class="container">
	<?php the_content(); ?>
</div>
<!-- /.container -->


<?php
get_footer();

?>