<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'hostim_parent_css' ) ):
    function hostim_parent_css() {
        wp_enqueue_style( 'hostim-child-style', trailingslashit( get_template_directory_uri() ) . 'style.css', array(  ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'hostim_parent_css', 10 );

// END ENQUEUE PARENT ACTION
