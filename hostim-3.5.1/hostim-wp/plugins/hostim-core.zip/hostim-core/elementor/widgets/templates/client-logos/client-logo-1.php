<div class="vps_scripts_slider_wrapper ">
	<div class="swiper vps-scripts-slider overflow-visible"
	     data-perpage="<?php echo esc_attr( $desktop_items ) ?>"
	     data-loop="<?php echo $carousel_loop == 'yes' ? 'true' : 'false' ?>"
	     data-autoplay="<?php echo $carousel_autoplay == 'yes' ? 'true' : 'false' ?>"
	     data-speed="<?php echo esc_attr( $slide_speed ) ?>"
	     data-space="<?php echo !empty( $item_space ) ? esc_attr( $item_space['size'] ) : '24' ?>"
		 data-delay="<?php echo esc_attr($slide_delay) ?>"
	     data-next=".swiper-next"
	     data-prev=".swiper-prev"
	     data-breakpoints='{"1399": {"slidesPerView": <?php echo esc_attr( $desktop_items ) ?>},"1024": {"slidesPerView": <?php echo esc_attr( $tablet_items ) ?>}, "768": {"slidesPerView": <?php echo esc_attr( $show_items_mobile ) ?>}, "360": {"slidesPerView": <?php echo esc_attr( $show_items_mobile ) ?>}}' >
		<div class="swiper-wrapper">
			<?php
			if( is_array( $logo_carousel ) ){
				foreach( $logo_carousel as $item ){ ?>
					<div class="vps-script-item text-center swiper-slide">
						<a <?php Hostimg_Core_Helper()->the_button($item['item_url']); ?>>
							<?php
							if( !empty( $item['icon_img']['url'] ) ){
								echo '<img src="'. esc_url( $item['icon_img']['url'] ) .'" alt="'. esc_attr( $item['title'] ) .'" class="img-fluid rounded-circle">';
							}

							if( !empty( $item['title'] ) ){
								echo '<h6 class="mb-0 mt-3">'. esc_html( $item['title'] ) .'</h6>';
							}
							?>
						</a>
					</div>
					<?php
				}
			}
			?>
		</div>
		<?php
		if( $is_navigation == 'yes' ){ ?>
			<div class="swiper-prev swiper-control-btn"><i class="fa-solid fa-arrow-left"></i></div>
			<div class="swiper-next swiper-control-btn"><i class="fa-solid fa-arrow-right"></i></div>
			<?php
		}
		?>
	</div>
</div>
