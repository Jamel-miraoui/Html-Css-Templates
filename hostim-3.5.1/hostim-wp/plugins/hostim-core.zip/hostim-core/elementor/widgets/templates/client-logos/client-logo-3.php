<div class="container-fluid container-xmax p-0">
    <div class="row g-0 justify-content-center">
        <div class="col-12">
            <div class="qty-brand-slider overflow-hidden">
                <div class="swiper-wrapper">
                    <?php
                    foreach($logo_carousel as $valu){ ?>
                        <div class="swiper-slide">
                            <div class="qty-brand">
                                <a <?php Hostimg_Core_Helper()->the_button($item['item_url']); ?>>
                                    <div class="qty-brand__img">
                                        <img src="<?php echo $valu['icon_img']['url']; ?>" alt="image" class="img-fluid">
                                    </div>
                                    <div class="qty-brand__text">
                                        <?php echo esc_html($valu['title']); ?>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>