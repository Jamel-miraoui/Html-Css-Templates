<div class="operating-systems">
	<div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
        <?php if ( !empty($title) ) : ?>
		    <h4 class="mb-0"><?php echo esc_html($title) ?></h4>
        <?php endif; ?>
		<div class="ops-slider-controls">
			<button type="button" class="ops-slider-btn btn-prev"><i class="fa-solid fa-arrow-left"></i></button>
			<button type="button" class="ops-slider-btn btn-next"><i class="fa-solid fa-arrow-right"></i></button>
		</div>
	</div>
	<div class="ops-slider swiper mt-4 overflow-hidden"
	     data-perpage="<?php echo esc_attr( $desktop_items ) ?>"
	     data-loop="<?php echo $carousel_loop == 'yes' ? 'true' : 'false' ?>"
	     data-autoplay="<?php echo $carousel_autoplay == 'yes' ? 'true' : 'false' ?>"
		 data-delay="<?php echo esc_attr($slide_delay) ?>"
	     data-speed="<?php echo esc_attr( $slide_speed ) ?>"
	     data-space="<?php echo !empty( $item_space ) ? esc_attr( $item_space['size'] ) : '24' ?>"
	     data-next=".btn-next"
	     data-prev=".btn-prev"
	     data-breakpoints='{"1399": {"slidesPerView": <?php echo esc_attr( $desktop_items ) ?>},"1024": {"slidesPerView": <?php echo esc_attr( $tablet_items ) ?>}, "768": {"slidesPerView": <?php echo esc_attr( $show_items_mobile ) ?>}, "360": {"slidesPerView": <?php echo esc_attr( $show_items_mobile ) ?>}}'
	>
		<div class="swiper-wrapper">
			<?php
			if( is_array( $logo_carousel2 ) ){
				foreach( $logo_carousel2 as $item ){ ?>
                    <div class="ops-slider-single bg-white py-3 px-4 rounded swiper-slide">
						<a <?php Hostimg_Core_Helper()->the_button($item['logo_url']); ?>>
							<?php echo wp_get_attachment_image($item['logo']['id'], 'full', '', [ 'class' => 'img-fluid' ]) ?>
						</a>
                    </div>
					<?php
				}
			}
			?>
		</div>
	</div>

</div>
