<?php

namespace Hostim\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{
	Group_Control_Box_Shadow,
	Utils,
	Widget_Base,
	Controls_Manager,
	Group_Control_Typography,
	Group_Control_Background
};

class Hostim_Countdown extends Widget_Base
{

	public function get_name()
	{
		return 'hostim-countdown';
	}

	public function get_title()
	{
		return esc_html__('Hostim Countdown', 'hostim-core');
	}

	public function get_icon()
	{
		return 'eicon-countdown';
	}

	public function get_script_depends()
	{
		return ['countdown'];
	}

	public function get_categories()
	{
		return ['hostim-elements'];
	}

	/**
	 * Name: register_controls
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @hostim
	 * Author: Themetags
	 */
	protected function register_controls()
	{
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @hostim
	 * Author: Themetags
	 */
	public function elementor_content_control()
	{


		$this->start_controls_section('countdown_section', [
			'label' => esc_html__('Countdown', 'hostim-core'),
		]);

		$this->add_control(
			'countdown_date',
			[
				'label' => esc_html__('Countdown Date', 'plugin-name'),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
			]
		);

		$this->add_responsive_control(
			'countdown_align',
			[
				'label' => __('Alignment', 'hostim-core'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'hostim-core'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'hostim-core'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __('Right', 'hostim-core'),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __('Justified', 'hostim-core'),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .hm2-section-title' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.6.0
	 * Package: @hostim
	 * Author: Themetags
	 */
	public function elementor_style_control()
	{
	}


	/**
	 * Name: render
	 * Desc: Widgets Render
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @hostim
	 * Author: Themetags
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		extract($settings);

		if (!empty($countdown_date)) {
			$due_date = date_create($countdown_date); ?>
			<ul class="countdown-timer sp-downcount-timer d-flex align-items-center" data-date="<?php echo esc_attr(date_format($due_date, 'm/j/Y h:i:s')) ?>">
				<li>
					<span class="days box">24</span>
					<span class="subtitle">Days</span>
				</li>
				<li>
					<span class="hours box">10</span>
					<span class="subtitle">Hour</span>
				</li>
				<li>
					<span class="minutes box">45</span>
					<span class="subtitle">Minutes</span>
				</li>
				<li>
					<span class="seconds box">10</span>
					<span class="subtitle">Sec</span>
				</li>
			</ul>
			<?php
		}

	}
}
