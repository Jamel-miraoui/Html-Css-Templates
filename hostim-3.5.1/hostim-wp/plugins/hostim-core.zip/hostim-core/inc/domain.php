<?php

/**
 * Domain
 *
 * @package Hostim
 * @author ThemeTags
 * @link https://themetags.com
 */
class Hostim_Domain
{
    /**
     * Instance .
     *
     * @var Hostim_Domain
     */
//	protected static $_instance = null;

    /**
     * Get Hostim_Domain instance .
     *
     * @return Hostim_Domain
     */
//	public static function instance() {
//
//		if ( is_null( self::$_instance ) ) {
//			self::$_instance = new self();
//		}
//
//	}

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('wp_ajax_nopriv_hostim_ajax_search_domain', array($this, 'ajax_search_domain'));
        add_action('wp_ajax_hostim_ajax_search_domain', array($this, 'ajax_search_domain'));
        add_action('wp_head', array($this, 'domain_js_file'));
        add_action('wdes_domain_verify_code', array($this, 'verify_code'));

    }

    /**
     * Admin ajax for domain.
     */
    function domain_js_file()
    {
        echo '<script>
            /*<![CDATA[*/
            var hostim_ajax_url = "' . admin_url('admin-ajax.php') . '";
            /*]]>*/
          </script>';
    }

    /**
     * Connect from whois server.
     *
     * @param string $domain the full domain that will checking.
     *
     * @return mixed|string
     */
    public function get_whois_server($domain)
    {

        $fp = stream_socket_client('whois.iana.org:43', $errno, $errstr, 30);
        if (!$fp) {
            echo "$errstr ($errno)<br />\n";
        } else {

            fputs($fp, $domain . "\r\n");
            $response_text = '';

            while (!feof($fp)) {
                $response_text .= fgets($fp, 128);
            }

            $response_server = '';

            if (strpos($response_text, 'but this server does not have') == 0) {
                if (strpos($domain, 'earth') == true) {
                    return $response_server = 'whois.nimzo98.com';
                }

                $split_whois = explode('whois: ', $response_text);
                $split_status = explode('status:', $split_whois[1]);
                $response_server = preg_replace('/\s+/', '', $split_status[0]);
            }


            return $response_server;
        }
    }

    /**
     * Check if domain is available.
     *
     * @param $whois_server
     * @param $domain
     *
     * @return array
     */
    public function check_available($whois_server, $domain)
    {
        if ($whois_server && $domain) {

            $fp = stream_socket_client($whois_server . ':43', $errno, $errstr, 30);
            if (!$fp) {
                echo "$errstr ($errno)<br />\n";
            } else {
                fputs($fp, $domain . "\r\n");
                $response = '';

                while (!feof($fp)) {
                    $response .= fgets($fp, 128);
                }

                //Fix for work with country extension
                $lowercase_response = strtolower($response);

                if (is_int(strpos($lowercase_response, 'domain name:'))) {
                    $result = true;
                } else {
                    $result = false;
                }

                return array(
                    'status' => $result,
                );
            }
        } else {
            return array(
                'status' => false,
            );
        }

    }

    /**
     * Get the domain result by ajax.
     */
    public function ajax_search_domain()
    {
        $domain = sanitize_text_field($_POST['domain']);
        $wmhcs_url = sanitize_text_field($_POST['whmcs_url']);



        $test = explode('.', $domain);

        if (is_array($test)) {
            if (!isset($test[1])) {
                $ext = '.com';
            } elseif ($test[0] === 'www') {
                $ext = $test[2];
                $n_domain = $test[1] . '.' . $test[2];
            } else {
                $ext = $test[1];
                $n_domain = $test[0] . '.' . $test[1];
            }
        }

        $suggestion = explode('.', $domain);
        $output = array(
            'status' => '',
            'domain' => '',
            'results_html' => '',
        );

        $whios_server = $this->get_whois_server($domain);



        if (empty($whios_server)) {

            $output = array(
                'status' => 'no_support',
                'domain' => $domain,
                'results_html' => esc_html__('Please check the domain name or extension', 'hostim-core'),
            );

        } else {

            $whois_server = $whios_server;
            $output = $this->check_available($whois_server, $domain);

            $output['status'] = ($output['status']) ? 'taken' : 'available';
            $output['domain'] = $domain;

            // result html.
            if ($output['status'] === 'available') {
                $output['results_html'] .= '<input type="hidden" name="domain" placeholder="' . esc_attr__('eg: example.com', 'hostim-core') . '" autocapitalize="none" value="'. $domain . '">';
                $output['results_html'] .= '<div class="result-wrapper alert-success"><i class="far fa-check-circle"></i>'. __('Congratulation', 'hostim-core').' <span class="available">'.$domain.' </span>' . __('is available!', 'hostim-core') . '<span class="reasult-info"><a href="' . $wmhcs_url . $domain . '" class="hostim-btn" target="_blank"><input type="button" class="wdes-purchase-btn template-btn primary-btn btn-small flex-shrink-0 border-0" value="' . esc_attr__('Purchase', 'hostim-core') . '"></a></span></div>';
            } else {
                $output['results_html'] .= '<div class="result-wrapper alert-danger"><span class="hostim-btn-token"><i class="fas fa-exclamation-circle icon-taken"></i><span class="available">'.$domain.' </span>' .' ' . __('is unavailable', 'hostim-core') . '</span>';
            }
        }

        wp_send_json($output);
    }

    /**
     * Verify code
     */
    public function verify_code()
    {
        echo '<input type="hidden" name="token" value="0811bf819565bf8142cc613d099e85a27ec1204c">';
    }


}

$obj = new Hostim_Domain();